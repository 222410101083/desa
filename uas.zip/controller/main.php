<?php
include_once 'auth_controller.php';
include_once 'artikel_controller.php';

require_once 'admin/dash_admin_controller.php';
require_once 'admin/ubahPassword.php';
require_once 'masyarakat/dash_masyarakat_controller.php';
include_once 'masyarakat/dash_masyarakat_controller.php';
include_once 'masyarakat/proposal_masyarakat_controller.php';
require_once 'pemerintah/dash_pemerintah_controller.php';
include_once 'masyarakat/aduan_masyarakat_controller.php';
include_once 'pemerintah/aduan_pemerintah_controller.php';
include_once 'pemerintah/proposal_pemerintah_controller.php';
require_once 'pemerintah/proposal_pemerintah_controller.php';
include_once 'masyarakat/profil_masyarakat.php';
include_once 'admin/artikel_admin_controller.php';
include_once 'pemerintah/profil_pemerintah_controller.php';


session_start();

