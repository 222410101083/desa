<?php
require_once 'env.php';

define('BASEURL', $_ENV['BASEURL']);