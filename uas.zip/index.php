<?php
include_once 'controller/routes.php';
// var_dump($_SERVER);